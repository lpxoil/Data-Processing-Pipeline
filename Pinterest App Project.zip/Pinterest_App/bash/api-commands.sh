# Commands for Pinterest App
python API/project_pin_API.py
python User_Emulation/user_posting_emulation.py
python Consumers/batch_consumer.py
python Consumers/streaming_consumer.py